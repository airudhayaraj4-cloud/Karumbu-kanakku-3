# கரும்பு கணக்கு (Karumbu Kanakku) - Android APK Build

இந்த கோப்புகளை உங்கள் GitHub Repository-ல் பதிவேற்றம் செய்தால், GitHub Actions தானாகவே Android APK-வை உருவாக்கித் தரும்!

## படிகள் (Steps):
1. GitHub-ல் ஒரு புதிய Repository (எ.கா: **karumbu-kanakku**) உருவாக்கவும்.
2. இந்த ZIP-ல் உள்ள அனைத்து கோப்புகளையும் (`index.html`, `manifest.json`, மற்றும் `.github/workflows/build.yml`) அங்கே Upload செய்யவும்.
3. கோப்புகளை பதிவேற்றியதும், உங்கள் GitHub பக்கத்தில் **"Actions"** என்ற பகுதிக்குச் செல்லவும்.
4. **"Build Android APK"** வேலை தானாகவே ஓடத் தொடங்கும் (சுமார் 2-3 நிமிடங்கள்).
5. அது முடிந்ததும், கீழே உள்ள **"Artifacts"** பகுதியில் **"Karumbu-Kanakku-Android-APK"** என்ற ஃபைலை கிளிக் செய்து உங்கள் போனில் பதிவிறக்கிக் கொள்ளலாம்!
